Updated 02/15/12

As of this date, this zip file contains three different programs:

SVGDraw01
JpgToSig-A-01
ShapeExtractor02

Read the following files to obtain usage information about each of the programs.

_SVGDraw01.ReadMeFirst.txt
_JpgToSig-A-01.ReadMeFirst.txt
_ShapeExtractor02.ReadMeFirst.txt

Extract all of the material from the zip file into an empty folder being careful to preserve the directory tree structure. Don't extract into the root directory. One user has reported problems accessing the Help file when the contents of the zip file were extracted into the root folder.

This program requires the Windows operating system.

Execute the files named Run<programName>.bat to run the programs.

It is not necessary for you to have Java or any other special software installed on your computer to run these programs. You should even be able to extract the contents of the zip file onto a USB flash drive and run the program on any Windows system, Version XP or later, with 32-bit or 64-bit hardware. Of course, you don't have to use a USB flash drive, I mention that simply to emphasize the flexibility that you have with this program.

baldwin@dickbaldwin.com

-end-